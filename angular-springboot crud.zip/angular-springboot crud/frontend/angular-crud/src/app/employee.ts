export class Employee {
    id: number;
    fullName: string;
    designation: string;
    salary: number;
}